#!/bin/bash
i=0
while read readline
do
args=(${readline})
echo ${args[0]}
perl -MLWP::Simple -e " print get '${args[0]}' " | cat >tabelog$i.txt
echo $i
i=$(($i+1))
done < ${1:?}
